module.exports = (year) => {
    return year % 12
}